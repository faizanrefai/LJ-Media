//
//  main.m
//  ARKitDemo
//
//  Created by Zac White on 8/1/09.
// Updated by Niels Hansen 12/19/09
//  Copyright Agilite Software 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
