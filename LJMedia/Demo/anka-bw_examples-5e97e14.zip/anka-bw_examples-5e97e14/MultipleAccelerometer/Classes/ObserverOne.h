//
//  ObserverOne.h
//  MultipleAccelerometer
//
//  Created by Andreas Katzian on 15.06.10.
//  Copyright 2010 Blackwhale GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ObserverOne : NSObject <UIAccelerometerDelegate> {

}

@end
