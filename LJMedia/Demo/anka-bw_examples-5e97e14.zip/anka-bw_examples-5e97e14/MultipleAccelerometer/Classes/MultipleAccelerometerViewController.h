//
//  MultipleAccelerometerViewController.h
//  MultipleAccelerometer
//
//  Created by Andreas Katzian on 15.06.10.
//  Copyright Blackwhale GmbH 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultipleAccelerometerViewController : UIViewController {

}

@end

