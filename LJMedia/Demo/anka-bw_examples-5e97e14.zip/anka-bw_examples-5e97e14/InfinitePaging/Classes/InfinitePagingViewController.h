//
//  InfinitePagingViewController.h
//  InfinitePaging
//
//  Created by Andreas Katzian on 08.07.10.
//  Copyright Blackwhale GmbH 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfinitePagingView.h"

@interface InfinitePagingViewController : UIViewController <InfinitePagingDataSource> {

}

@end

