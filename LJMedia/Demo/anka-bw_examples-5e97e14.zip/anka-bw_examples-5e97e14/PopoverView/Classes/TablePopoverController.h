//
//  TablePopoverController.h
//  PopoverView
//
//  Created by Andreas Katzian on 04.10.10.
//  Copyright 2010 Blackwhale GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TablePopoverController : UITableViewController {

}

@end
